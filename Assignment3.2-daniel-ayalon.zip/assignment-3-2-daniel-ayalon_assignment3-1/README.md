# assignment3.2 - Ayalon Azlan and Daniel Kolbasov

## API - fixed
* [Link to API](https://app.swaggerhub.com/apis/Daniel202194/foodRecipes/1.0.0)

## More Information
* Ayalon Azlan 303031686
* Daniel Kolbasov 311286397
