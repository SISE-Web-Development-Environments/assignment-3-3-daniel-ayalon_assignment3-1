-- DROP TABLE users
-- DROP TABLE watchedRecipes
-- DROP TABLE familyRecipes
-- DROP TABLE favoritesRecipes
-- DROP TABLE personalRecipes
ALTER TABLE personalRecipes
    DROP COLUMN likes