

insert into personalRecipes(recipe_id,[user_id],author,recipe_name,durationTime,[image],vegetarian,gluten,vegan)
values(1,2,'Ayalon Azlan','majadra',45,'https://res.cloudinary.com/du8fkyylb/image/upload/v1591733744/personal_Ayalon/Majadra-1.jpg.839x0_q71_crop-scale_y7lti9.jpg',
1,0,1)



insert into personalRecipes(recipe_id,[user_id],author,recipe_name,durationTime,[image],vegetarian,gluten,vegan)
values(2,2,'Ayalon Azlan','Sour Cream Chip Muffins',70,'https://res.cloudinary.com/du8fkyylb/image/upload/v1591734785/personal_Ayalon/exps10111_MRR143297C09_10_2b-696x696_igmveo.jpg',
1,1,1)


insert into personalRecipes(recipe_id,[user_id],author,recipe_name,durationTime,[image],vegetarian,gluten,vegan)
values(3,2,'Ayalon Azlan','Caramel Pecan Rolls',35,'https://res.cloudinary.com/du8fkyylb/image/upload/v1591735121/personal_Ayalon/Caramel-Pecan-Rolls_EXPS_BMZ17_3319_C10_28_2b-696x696_gqhpba.jpg',
1,1,1)


insert into personalRecipes(recipe_id,[user_id],author,recipe_name,durationTime,[image],vegetarian,gluten,vegan)
values(4,1,'Daniel kolbasov ','Peach Smoothie',5,'https://res.cloudinary.com/du8fkyylb/image/upload/v1591735292/personal_Ayalon/exps20930_HR143571C09_16_1b-696x696_qsxpdk.jpg',
1,0,1)



insert into personalRecipes(recipe_id,[user_id],author,recipe_name,durationTime,[image],vegetarian,gluten,vegan)
values(5,1,'Daniel kolbasov ','Grilled Apple Tossed Salad',25,'https://res.cloudinary.com/du8fkyylb/image/upload/v1591735508/personal_Ayalon/Grilled-Apple-Tossed-Salad_EXPS_SDAS17_33475_B04_06_4b-696x696_ablivb.jpg',
1,0,1)


insert into personalRecipes(recipe_id,[user_id],author,recipe_name,durationTime,[image],vegetarian,gluten,vegan)
values(6,1,'Daniel kolbasov ','pizza',45,'https://res.cloudinary.com/du8fkyylb/image/upload/v1591735634/personal_Ayalon/BLT-Pizza_exps18811_TG133212B05_24_3b_RMS-696x696_xioovu.jpg',
1,1,1)