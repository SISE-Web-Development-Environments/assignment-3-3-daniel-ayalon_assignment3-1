Insert  into favoritesRecipes (recipe_id, user_id, recipe_name, durationTime, image, likes, vegetarian, gluten, vegan)
values (1,1,'pizza',40,'imagess',4,0,0,0);